using System;
using UnityEngine;

namespace Fusion.VR.Cosmetics
{
    // So we can see it in the editor
    [Serializable]
    public class PlayerCosmeticSlot
    {
        public string SlotName;
        public Transform Slot;
    }
}